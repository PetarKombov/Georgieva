﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proekt_Fakultet
{
    public abstract class Ychenik
    {
        protected string name;
        protected string grupa;
        protected string specialnost;
        public Ychenik(string name, string grupa, string specialnost)
        {
            this.name = name;
            this.specialnost = specialnost;
            this.grupa = grupa;
        }
        public abstract double AverageOcenka();

        
    }
}
