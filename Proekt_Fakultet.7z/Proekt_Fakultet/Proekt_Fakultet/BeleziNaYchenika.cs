﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proekt_Fakultet
{
    public class BeleziNaYchenika : Ychenik, IPrint
    {
        private string fakultet;
        private int fakultetNomer;
        private List<double> ocenki;


        public string Fakultet
        {
            get { return fakultet; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("Fakultet");
                }
                this.fakultet = value;
            }
        }
        public int FakultetNomer
        {
            get { return fakultetNomer; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("FakultetNomer");
                }
                this.fakultetNomer = value;
            }
        }
        public List<double> Ocenki
        {
            get { return ocenki; }
            set
            {
                if (value == null || value.Count != 5)
                {
                    throw new ArgumentOutOfRangeException("value");
                }
                ocenki = value;
            }
        }
        public BeleziNaYchenika(string name,string grupa, string specialnost, string fakultet, int fakultetNomer, List<double> ocenki) : base(name, specialnost,grupa)
        {
           this.Fakultet = fakultet;
           this.FakultetNomer = fakultetNomer;
           this.Ocenki = ocenki;
        }
        public string ReturnName()
        {
            return this.name;
        }
        public string ReturnSpecialnost()
        {
            return this.specialnost;
        }
        public override double AverageOcenka()
        {
            double totalOcenki = ocenki.Sum();
            int countOcenki = ocenki.Count();

            return totalOcenki / countOcenki;
        }

        public virtual string Print()
        {
           return $"Fakultet: {Fakultet}, Fakulteten Nomer: {FakultetNomer}, Specialnos: {specialnost}, Ocenki: {string.Join(", ", Ocenki)}, Sreden Uspeh: {Ocenki.Average():F2}";
        }

    }
}
