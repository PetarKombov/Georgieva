﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proekt_Fakultet
{
    //public class IComparerYchenik:IComparer<BeleziNaYchenika>
    //{
    //    public int Compare(BeleziNaYchenika x, BeleziNaYchenika y)
    //    {
    //        int result;
    //        result = x.ReturnSpecialnost().CompareTo(y.ReturnSpecialnost());
    //        return result;
    //    }

    //}
}
