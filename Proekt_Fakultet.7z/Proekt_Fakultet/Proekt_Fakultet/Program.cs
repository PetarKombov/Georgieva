﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proekt_Fakultet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<BeleziNaYchenika> list = new List<BeleziNaYchenika>();

            BeleziNaYchenika elementi;
            

            // Въвеждане на данни за студенти
            Console.WriteLine("Enter the number of students: ");
            int studentCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < studentCount; i++)
            {
                Console.WriteLine($"Enter data for student {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Grupa: ");
                string grupa = Console.ReadLine();

                Console.Write("Specialnost: ");
                string specialnost = Console.ReadLine();

                Console.Write("Fakultet: ");
                string fakultet = Console.ReadLine();

                Console.Write("Fakultet Nomer: ");
                int fakultetNomer = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter 5 grades:");
                List<double> ocenki = new List<double>();

                for (int j = 0; j < 5; j++)
                {
                    Console.Write($"Grade {j + 1}: ");
                    double grade = double.Parse(Console.ReadLine());
                    ocenki.Add(grade);
                }

                list.Add(new BeleziNaYchenika(name, grupa, specialnost.Trim(), fakultet, fakultetNomer, ocenki));
            }


            //1 izhod vsichki vuvedeni danni
            Console.WriteLine("-------------------------------------------");
            list.ForEach(x => Console.WriteLine(x.Print()));

            //2 izhod
            Console.WriteLine("-------------------------------------------");
            Console.Write("Specialnost za studenta ");

            //vuvejdame nqkva specialnost s koqto da sravnqvame
            string specialityToFind = Console.ReadLine().Trim();

            Console.WriteLine($"Studenti v {specialityToFind} specialnost:");
            foreach (BeleziNaYchenika student in list)
            {
                if (student.ReturnSpecialnost() == specialityToFind)
                {
                    Console.WriteLine(student.Print());
                }
            }


            //3 izhod
            Console.WriteLine("-------------------------------------------");
            double average;
            foreach (BeleziNaYchenika item in list)
            {
                average = item.AverageOcenka();
                Console.WriteLine($"Sredna ocenka za uchenika: {average:f2} ");
            }


            //4 izhod
            // Извежда данните за студента с най-висок среден успех;

            Console.WriteLine("-------------------------------------------");
            var dataForHighestAverageGrades = list.OrderBy(x => x.AverageOcenka()).Last();
            list.ForEach(x => Console.WriteLine(x.Print()));
            Console.WriteLine("Nai visoka ocenka");
            Console.WriteLine(dataForHighestAverageGrades.Print());

            //5

        }
    }
}
